namespace SharpShell.Interop
{
    public enum DIB
    {
        DIB_RGB_COLORS = 0,
        DIB_PAL_COLORS = 1
    }
}